@extends('layouts.app')

@section('title', 'Daftar Buku')

@section('content')
<div class="flex items-center justify-between mb-4">
    <h2 class="text-2xl font-bold">Daftar Buku</h2>
    <a href="/books/add" class="bg-blue-700 text-white px-4 py-2 rounded">+ Tambah Buku</a>
</div>

<div class="bg-white rounded shadow-md overflow-x-auto">
    <table class="w-full text-left">
        <thead class="bg-gray-200">
            <tr>
                <th class="p-3">No</th>
                <th class="p-3">Judul</th>
                <th class="p-3">Penulis</th>
                <th class="p-3">Penerbit</th>
                <th class="p-3">Tahun</th>
                <th class="p-3">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($books as $book)
            <tr class="border-t">
                <td class="p-3">{{ $loop->iteration }}</td>
                <td class="p-3">{{ $book->title }}</td>
                <td class="p-3">{{ $book->author }}</td>
                <td class="p-3">{{ $book->publisher }}</td>
                <td class="p-3">{{ $book->year }}</td>
                <td class="p-3 space-x-2">
                    <a href="/books/edit/{{ $book->id }}" class="text-blue-700 underline">Edit</a>
                    <a href="/books/delete/{{ $book->id }}" class="text-red-600 underline" onclick="return confirm('Yakin hapus buku ini?')">Hapus</a>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="p-3 text-center text-gray-500">Belum ada data buku.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
