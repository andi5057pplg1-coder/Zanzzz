<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
    <h2 class="text-2xl font-bold">Daftar Buku</h2>
    <a href="/books/add" class="bg-blue-700 text-white px-4 py-2 rounded">+ Tambah Buku</a>
</div>

<div class="bg-white rounded shadow-md overflow-x-auto">
    <table class="w-full text-left">
        <thead class="bg-gray-200">
            <tr>
                <th class="p-3">No</th>
                <th class="p-3">Judul</th>
                <th class="p-3">Penulis</th>
                <th class="p-3">Penerbit</th>
                <th class="p-3">Tahun</th>
                <th class="p-3">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-t">
                <td class="p-3"><?php echo e($loop->iteration); ?></td>
                <td class="p-3"><?php echo e($book->title); ?></td>
                <td class="p-3"><?php echo e($book->author); ?></td>
                <td class="p-3"><?php echo e($book->publisher); ?></td>
                <td class="p-3"><?php echo e($book->year); ?></td>
                <td class="p-3 space-x-2">
                    <a href="/books/edit/<?php echo e($book->id); ?>" class="text-blue-700 underline">Edit</a>
                    <a href="/books/delete/<?php echo e($book->id); ?>" class="text-red-600 underline" onclick="return confirm('Yakin hapus buku ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="p-3 text-center text-gray-500">Belum ada data buku.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpus-digital\resources\views/books.blade.php ENDPATH**/ ?>