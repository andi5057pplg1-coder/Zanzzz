<?php $__env->startSection('title', 'Edit Buku'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-bold mb-4">Edit Data Buku</h2>
<form action="/books/edit/<?php echo e($book->id); ?>" method="POST" class="bg-white p-6 rounded shadow-md space-y-4">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" value="<?php echo e($book->title); ?>" class="w-full border p-2 rounded" required>
    <input type="text" name="author" value="<?php echo e($book->author); ?>" class="w-full border p-2 rounded" required>
    <input type="text" name="publisher" value="<?php echo e($book->publisher); ?>" class="w-full border p-2 rounded">
    <input type="number" name="year" value="<?php echo e($book->year); ?>" class="w-full border p-2 rounded">
    <button type="submit" class="bg-blue-700 text-white px-4 py-2 rounded">Perbarui</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpus-digital\resources\views/edit-book.blade.php ENDPATH**/ ?>