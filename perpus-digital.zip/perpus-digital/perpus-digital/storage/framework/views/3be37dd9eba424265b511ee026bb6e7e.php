<?php $__env->startSection('title', 'Tambah Buku'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-bold mb-4">Tambah Buku Baru</h2>
<form action="/books/add" method="POST" class="bg-white p-6 rounded shadow-md space-y-4">
    <?php echo csrf_field(); ?>
    <input type="text" name="title" placeholder="Judul Buku" class="w-full border p-2 rounded" required>
    <input type="text" name="author" placeholder="Penulis" class="w-full border p-2 rounded" required>
    <input type="text" name="publisher" placeholder="Penerbit" class="w-full border p-2 rounded">
    <input type="number" name="year" placeholder="Tahun Terbit" class="w-full border p-2 rounded">
    <button type="submit" class="bg-blue-700 text-white px-4 py-2 rounded">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpus-digital\resources\views/add-book.blade.php ENDPATH**/ ?>