<?php

use Illuminate\Support\Facades\Route;
use App\Models\Book;
use Illuminate\Http\Request;

Route::get('/', function () {
    return view('welcome');
});

// C. Menampilkan semua buku
Route::get('/books', function () {
    $books = Book::all();
    return view('books', compact('books'));
});

// D. Form tambah buku
Route::get('/books/add', function () {
    return view('add-book');
});

Route::post('/books/add', function (Request $request) {
    App\Models\Book::create($request->all());
    return redirect('/books');
});

// E. Edit & hapus buku
Route::get('/books/edit/{id}', function ($id) {
    $book = App\Models\Book::findOrFail($id);
    return view('edit-book', compact('book'));
});

Route::post('/books/edit/{id}', function (Request $request, $id) {
    $book = App\Models\Book::findOrFail($id);
    $book->update($request->all());
    return redirect('/books');
});

Route::get('/books/delete/{id}', function ($id) {
    App\Models\Book::findOrFail($id)->delete();
    return redirect('/books');
});
