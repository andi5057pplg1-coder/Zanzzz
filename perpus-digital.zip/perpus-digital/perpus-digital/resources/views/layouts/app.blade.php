<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Perpustakaan Digital</title>
    {{-- Tailwind via CDN agar tidak perlu npm install / npm run dev --}}
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">
    <nav class="bg-blue-700 text-white">
        <div class="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
            <span class="font-bold text-lg">Perpustakaan Digital</span>
            <div class="space-x-4">
                <a href="/books" class="hover:underline">Daftar Buku</a>
                <a href="/books/add" class="hover:underline">Tambah Buku</a>
            </div>
        </div>
    </nav>

    <main class="max-w-4xl mx-auto px-4 py-8">
        @yield('content')
    </main>
</body>
</html>
